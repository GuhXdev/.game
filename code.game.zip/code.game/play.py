

def damagePlayer(player, damage):
    player["life"] -= damage

    print("Você sofreu dano!!")
    print("Sua vida atual é:", player["life"])


def damageNpc(npc, damage):
    npc["life"] -= damage

    print("O monstro sofreu dano!!")
    print("A vida atual do monstro é:", npc["life"])
    print("                                                                      ")


def updatePlayer(player):
    player["life"] += 3
    player["attack"] += 3
    player["level"] += 2
    player["Especial ataque"] += 5

    randomItem(player)

    print("Seu personagem evoluiu!!")
    print("                                                                      ")
    print("Sua vida é:", player["life"])
    print("                                                                      ")
    print("Seu ataque é:", player["attack"])
    print("                                                                      ")
    print("Seu nível é:", player["level"])
    print("                                                                      ")
    print("Recompensa:", player["inventario"])



def showInventory(player):

    print("Inventário do jogador:")

    for item in player["inventario"]:
        print(item)

    print("")
    print("1: Poção de cura")
    print("2: Armadura")
    print("3: Elixir")
    print("                                                                      ")

    chose = input("Escolha um item para usar (digite o número correspondente): ")

    if chose == "1":
        if player["inventario"]["porcao de cura"] > 0:
            player["life"] += 7
            player["inventario"]["porcao de cura"] -= 1
            print("Você usou uma poção de cura!")
            print("Sua vida aumentou para:", player["life"])
            print("                                                                      ")
        else:
            print("Você não tem poções de cura suficientes!")

    elif chose == "2":
        if player["inventario"]["armadura"] > 0:
            player["attack"] += 9
            player["inventario"]["armadura"] -= 1
            print("Você usou uma armadura!")
            print("Seu ataque aumentou para:", player["attack"])
        else:
            print("Você não tem armaduras suficientes!")

    elif chose == "3":
        if player["inventario"]["elixir"] > 0:
         player["quantidade_especial"] += 3
         player["inventario"]["elixir"] -= 1
         print("Você usou um elixir!")
         print(
            "Sua quantidade de ataques especiais aumentou para:",
            player["quantidade_especial"]
        )
        print("                                                                      ")

    else:
        print("Opção inválida. Nenhum item foi usado.")
        
    

def randomItem(player):
    import random

    items = ["porcao de cura", "armadura", "elixir"]
    item = random.choice(items)

    player["inventario"][item] += 1

    print("Você recebeu um item aleatório!")
    print("Item recebido:", item)
    print("                                                                      ")
    





