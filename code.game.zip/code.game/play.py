

def damagePlayer(player, damage):
    player["life"] -= damage

    print("Você sofreu dano!!")
    print("Sua vida atual é:", player["life"])


def damageNpc(npc, damage):
    npc["life"] -= damage

    print("O monstro sofreu dano!!")
    print("A vida atual do monstro é:", npc["life"])


def updatePlayer(player):
    player["life"] += 3
    player["attack"] += 3
    player["level"] += 2
    player["inventario"].append(randomItem(player)) 
    player["Especial ataque"] += 5

    print("Seu personagem evoluiu!!")
    print("Sua vida é:", player["life"])
    print("Seu ataque é:", player["attack"])
    print("Seu nível é:", player["level"])
    print("Recompensa:", player["inventario"])



def showInventory(player):
    print("Inventário do jogador:")
    for item in player["inventario"]:
        print(item)
        print("1: porção de cura")
        print("2: Armadura")
        print("3: Elixir")

    chose = input("Escolha um item para usar (digite o número correspondente): ")
    if chose == "1":
        player["life"] += 7
        print("Você usou uma porção de cura! Sua vida aumentou para:", player["life"])
    elif chose == 2:
        player["attack"] += 9
        print("Você usou uma armadura! Seu ataque aumentou para:", player["attack"])
    elif chose == 3:
        player["quantidade_especial"] += 3
    else:
        print("Opção inválida. Nenhum item foi usado.")

        
    

def randomItem(player):
    import random
    items = ["porção de cura", "Armadura","Elixir"]
    item = random.choice(items)
    player["inventario"].append(item)
    print("Você encontrou um item:", item)






