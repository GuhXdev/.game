import random

npc = 0
hp = 0
atack = 0
level = 0





def createNpc():
    npc = {
        "life": random.randint(10, 30),
        "attack": random.randint(1, 10),
        "level": random.randint(1, 5)
    }

    print("um monstro apareceu!")
    print("                         ")
    print("_____________________")
    print("Vida:", npc["life"])
    print("_____________________")
    print("Ataque:", npc["attack"])
    print("_____________________")
    print("Nível:", npc["level"])

    return npc



def npcAttack(player, npc):
    player["life"] -= npc["attack"]

    print("O mostro atacou você!")
    print("                         ")
    print("Dano recebido:", npc["attack"])
    print("Sua vida:", player["life"])








