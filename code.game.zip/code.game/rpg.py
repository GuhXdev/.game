import random
import play

npc = 0
hp = 0
atack = 0
level = 0





def createNpc():
    npc = {
        "life": random.randint(10, 30),
        "attack": random.randint(1, 10),
        "level": random.randint(1, 5)
    }

    print("um monstro apareceu!")
    print("                         ")
    print("_____________________")
    print("Vida:", npc["life"])
    print("_____________________")
    print("Ataque:", npc["attack"])
    print("_____________________")
    print("Nível:", npc["level"])
    print("                                                                      ")

    return npc



def npcAttack(player, npc):
    player["life"] -= npc["attack"]

    print("O mostro atacou você!")
    print("                         ")
    print("Dano recebido:", npc["attack"])
    print("Sua vida:", player["life"])
    print("                                                                      ")

def createBoss():
    boss = {
        "life": random.randint(200, 500),
        "attack": random.randint(20, 40),
        "level": random.randint(50, 100)
    }

    print("O chefe final apareceu!")
    print("                         ")
    print("_____________________")
    print("Vida:", boss["life"])
    print("_____________________")
    print("Ataque:", boss["attack"])
    print("_____________________")
    print("Nível:", boss["level"])
    print("                                                                      ")

    return boss





def finalBoss(player, boss):
    player["life"] -= boss["attack"]

    print("O chefe final atacou você!")
    print("                         ")
    print("Dano recebido:", boss["attack"])
    print("Sua vida:", player["life"])
    print("                                                                      ")


def attackBoss(player, boss):
    boss["life"] -= player["attack"]

    print("Você atacou o chefe final!")
    print("                         ")
    print("Dano causado:", player["attack"])
    print("Vida do chefe final:", boss["life"])
    print("                                                                      ")


def playerAttack(player, boss):
    while True:
        print("Escolha uma ação:")
        print("1. Atacar")
        print("2. Usar ataque especial")
        print("3. Fugir")
        action = input("Digite o número da ação desejada: ")

        if action == "1":
            attackBoss(player, boss)

            if boss["life"] <= 0:
                print("Você derrotou o chefe final!")
                print("                                                                      ")
                return "venceu"

            finalBoss(player, boss)

            if player["life"] <= 0:
                print("Você foi derrotado pelo chefe final!")
                print("                                                                      ")
                return "perdeu"

        elif action == "2":
            if player["quantidade_especial"] > 0:
                player["quantidade_especial"] -= 1
                print("Você usou um ataque especial!")
                print("Quantidade restante de ataques especiais:", player["quantidade_especial"])
                print("                         ")
                boss["life"] -= player["Especial ataque"]
                print("Dano causado pelo ataque especial:", player["Especial ataque"])
                print("Vida do chefe final:", boss["life"])
                print("                                                                      ")

                if boss["life"] <= 0:
                    print("Você derrotou o chefe final!")
                    print("                                                                      ")
                    return "venceu"

                finalBoss(player, boss)

                if player["life"] <= 0:
                    print("Você foi derrotado pelo chefe final!")
                    print("                                                                      ")
                    return "perdeu"
            else:
                print("Você não tem ataques especiais restantes!")

        elif action == "3":
            print("Você fugiu da batalha!")
            return "fugiu"

        elif action == "4":
            print("                                                                                    ")
            play.showInventory(player)

        else:
         print("Opção inválida! Tente novamente.")





