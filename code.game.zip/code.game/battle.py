
import play
import rpg
import time


def startBattle(player, npc):

    print("Você está sendo atacado!!")
    print("                         ")

    time.sleep(2)

    while player["life"] > 0 and npc["life"] > 0:

        print("\nEscolha uma ação:")
        print("1. Atacar")
        print("2. Fugir")
        print("3. Inventário")
        print("4. Especial ataque")
        print("                         ")

        action = input("Digite o número da ação desejada: ")


        if action == "1":

            play.damageNpc(npc, player["attack"])
            print("                         ")

            if npc["life"] <= 0:
                print("Você derrotou o inimigo!")
                print("                         ")
                play.updatePlayer(player)
                play.randomItem(player)
                return "venceu"

                
            

            rpg.npcAttack(player, npc)

            if player["life"] <= 0:
                print("Você foi derrotado!")
                
            return "perdeu"

        elif action == "2":

            print("Você fugiu da batalha!")
            return "fugiu"

        elif action == "3":

            play.showInventory(player)

        elif action == "4":
            if player["quantidade_especial"] > 0:
                player["quantidade_especial"] -= 1
                print("Você usou um ataque especial!")
                print("Quantidade restante de ataques especiais:", player["quantidade_especial"])
                print("                         ")
                play.damageNpc(npc, player["Especial ataque"])
                print("                         ")

                if npc["life"] <= 0:
                    print("Você derrotou o inimigo!")
                    print("                         ")
                    play.updatePlayer(player)
                    play.randomItem(player)

                    break

                rpg.npcAttack(player, npc)

                if player["life"] <= 0:
                    print("Você foi derrotado!")
                    break
            play.damageNpc(npc, player["Especial ataque"])

     

        else:

            print("Ação inválida!")
    

     