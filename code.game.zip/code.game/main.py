import rpg
import battle
import play
import time

print("monster rpg")
print("")
print("novo jogo iniciado")
print("")
print("pressione F para sair")
print("")
print("pressione Y para iniciar")

while True:

    start = input("pressione para continuar: ").lower()

    if start == "y":

        print("")
        print("iniciando sua jornada")
        print("")

        player_name = input("digite o nome do seu personagem: ").lower()

        def createPlayer():

            player = {
                "name": player_name,
                "life": 10,
                "attack": 5,
                "level": 1,
                "inventario":[],
                "Especial ataque": 15,
                "quantidade_especial": 3

            }

            print("Personagem criado com sucesso!")
            print("")
            print("Nome:", player["name"])
            print("_____________________")
            print("Vida:", player["life"])
            print("_____________________")
            print("Ataque:", player["attack"])
            print("_____________________")
            print("Nível:", player["level"])
            print("_____________________")
            print("Especial ataque:", player["Especial ataque"])
            print("_____________________")
            print("Inventário:", player["inventario"])

            return player

        player = createPlayer()
        break

    elif start == "f":

        print("saindo do jogo")
        print("VOCÊ É FRACO HAHAHA")
        exit()

    else:

        print("opção inválida!")

batalhas_vencidas = 0

while batalhas_vencidas < 5:

    time.sleep(1)

    npc = rpg.createNpc()

    time.sleep(1)

    resultado = battle.startBattle(player, npc)

    if resultado == "perdeu":

        print("Game over")

        player["life"] = 10
        player["attack"] = 5
        player["level"] = 1
        player["Especial ataque"] = 15
        player["quantidade_especial"] = 3
        player["inventario"] = []

        break

    elif resultado == "fugiu":

        print("Você fugiu da batalha!")
        time.sleep(1)

    elif resultado == "venceu":

        batalhas_vencidas += 1

        print("Vitória conquistada!")
        print(f"Batalhas vencidas: {batalhas_vencidas}/5")
        time.sleep(1)


if batalhas_vencidas == 5:

    print("________________")
    print("Você venceu as 5 batalhas, parabéns!!")
    time.sleep(2)
    print("")
    print("Prepare-se para o grande desafio, hahaha!!")


