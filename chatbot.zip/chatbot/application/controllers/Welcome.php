<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	private $token = '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';
	private $modelo = 'meta-llama/Llama-3.1-8B-Instruct';
	private $system_prompt = 'vc e uma pizzaria';
	public function index()
	{
		$data['historico'] = $this->session->userdata('chat') ?? [];
		$this->load->view('chatbot', $data);
	}
	public function limpar()
	{
		$this->session->unset_userdata('chat');
		redirect('');
	}
	
	public function enviar()
	{
		$mensagem = $this->input->post('mensagem');
		$historico = $this->session->userdata('chat') ?? [];

		$historico[] = [
			'role' => 'user',
			'content' => $mensagem
		];

		$resposta = $this->perguntar_ia($historico);
		$historico[] = [
			'role' => 'assistant',
			'content' => $resposta
		];

		$this->session->set_userdata('chat', $historico);

		redirect('');
	}

	private function perguntar_ia($mensagem)
	{
		$url = 'https://router.huggingface.co/v1/chat/completions';


		$body = json_encode([
			'model' => $this->modelo,
			'messages' => $mensagem
		]);

		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

		// 7 aqui falamos quais os dados vão pelo header da requisição

		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $this->token,
			'Content-Type: application/json'
		]);

		// 8 executa e fecha a sessao
		$retorno = curl_exec($ch);
		curl_close($ch);

		// 9 como a resposta vai vim em json vamos converter ela

		$dados = json_decode($retorno);

		// 10 a fala do bot fica naquele caminho que vimos no postman

		if (isset($dados->choices[0]->message->content)) {
			return $dados->choices[0]->message->content;
		}

		return 'Não foi possivel gerar uma resposta';
	}
}
