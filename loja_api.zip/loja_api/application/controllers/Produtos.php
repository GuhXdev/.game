<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produtos extends CI_Controller {

	public function index()
	 {
		$produtos = $this->db->get('produtos')->result_array();

		$this->output
		   ->set_content_type('application/json')
		   ->set_status_header(200)
		   ->set_output(json_encode($produtos));

	
	}

	public function buscar($id){
		$produto = $this->db
		            ->get_where('produtos',['id'=> $id])
					->row_array();

		if (!$produto) {
			return $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_output(json_encode(['erro' => 'Não foi possivel encontrar esse id']));
			
			
		}
		
	  
		$this->output
		   ->set_content_type('appplication/json')
		   ->set_status_header(200)
		   ->set_output(json_encode($produto));



	}


	public function criar() {
		$produtos = json_decode(file_get_contents('php://input'), true);
		if(empty($produtos['nome']) || !isset($produtos['preco'])){
			return $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_output(json_encode(['erro' => 'Nome e preco são obrigatorio']));
		     
		}
		
	
		
        $this->db->insert('produtos',$produtos);
	    $id = $this->db->insert_id();

		$this->output
		 ->set_content_type('application/json')
		 ->set_status_header(201)
		 ->set_output(json_encode(['id' => $id] + $produtos));


	}
	public function atualizar($id){
		$produto = $this->db
		            ->get_where('produtos',['id'=> $id])
					->row_array();

		if (!$produto) {
			return $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_output(json_encode(['erro' => 'Não foi possivel encontrar esse id']));
			
		}

		$dados = json_decode(file_get_contents('php://input'),true);

		if(empty($dados['nome']) || empty($dados['preco'])){
			return $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_output(json_encode(['erro' => 'Nome e preco são obrigatorio']));
		     
		}

		$this->db->where(['id' =>$id])->update('produtos', $dados);

		$this->output
		   ->set_content_type('application/json')
		   ->set_status_header(200)
		   ->set_output(json_encode(['id' => $id] + $dados));


	}

	public function apagar(){
		$produto = $this->db
		            ->get_where('produtos',['id'=> $id])
					->row_array();

		if (!$produto) {
			return $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_output(json_encode(['erro' => 'Não foi possivel encontrar esse id']));
	}  
	    $this->where(['id'=> $id])->delete('produtos');
		$this->output
		   ->set_content_type('application/json')
		   ->set_status_header(200)
		   ->set_output(json_encode(['mensagem' => 'produto deletado com sucesso']));


	  
	
}
}