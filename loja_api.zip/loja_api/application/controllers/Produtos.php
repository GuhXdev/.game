<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produtos extends CI_Controller {

	public function index()
	 {
		$produtos = $this->db->get('produtos')->result_array();

		$this->output
		   ->set_content_type('appplication/json')
		   ->set_status_header(200)
		   ->set_output(json_encode($produtos));

	
	}
	public function criar() {
		$produtos = json_decode(file_get_contents('php://input'), true);
		if(!empty($produtos['nome'] || !empty($produto['preco']))){
		   $this->db->insert('produtos',$produtos);
		   $id = $this->db->insert_id();

		   $this->output
		     ->set_content_type('application/json')
			 ->set_status_header(201)
			 ->set_oputput(json_decode(['id' => $id + $produtos]));
		}
		else{
			$this->output
		     ->set_content_type('application/json')
			 ->set_status_header(400)
			 ->set_oputput(json_decode(['erro' => 'Nome e preco são obrigatorio']));
		}


	}
}
