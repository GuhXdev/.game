<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['produtos']['GET'] = 'produtos';
$route['produtos']['POST'] = 'produtos/criar';
$route['produtos/(:num)']['GET'] = 'produtos/buscar/$1';
$route['produtos/(:num)']['PUT'] = 'produtos/atualizar/$1';
$route['produtos/(:num)']['DELETE'] = 'produtos/apagar/$1';
